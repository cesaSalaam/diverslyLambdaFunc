from openai import OpenAI
import os


def lambda_handler(event, context):
    client = OpenAI(api_key=os.getenv("API_KEY"))

    txt = "he kindad retarded"

    completion = client.chat.completions.create(
        model="ft:gpt-4a-mini-2024-07-18:personal::9yqEn0Cw",
        messages=[
            {"role": "system",
             "content": "You are a bias and offensive content correction agent. You help to label and correct biases in writing. You label biases based on 7 categories"},
            {"role": "user",
             "content": f"Identify and correct the biases in [TEXT]. If there is more than one bias identified in the text, label both. TEXT= " + txt}
        ]
    )

    response = completion.choices[0].message.content

    print(f"Response: {response}")

    return {
        'statusCode': 200,
        'body': response
    }